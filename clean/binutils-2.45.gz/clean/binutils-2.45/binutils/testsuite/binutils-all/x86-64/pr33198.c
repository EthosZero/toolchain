void
foo (void)
{
}
